from machine import Pin
from time import sleep
led = Pin(14,Pin.OUT)
btn = Pin(12,Pin.IN, Pin.PULL_DOWN)
while True:
    if btn.value() == 1:
        led.on()
    else:
        led.off()
    sleep(0.05)