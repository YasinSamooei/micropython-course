import machine

import time

relay_pin = machine.Pin(13, machine.Pin.OUT)

# Turn on the relay for 1 second

relay_pin.on()

time.sleep(1)

# Turn off the relay

relay_pin.off()
